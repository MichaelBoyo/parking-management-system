import loginPageImage from './login-page-image.png';

import Logo from './Logo';

export { loginPageImage, Logo };
