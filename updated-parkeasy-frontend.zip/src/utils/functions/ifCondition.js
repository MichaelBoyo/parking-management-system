const ifCondition = (condition, then, otherwise) =>
  condition ? then : otherwise;

export default ifCondition;
