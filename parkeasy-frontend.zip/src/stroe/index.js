import { createContext, useState } from "react";

export const UserContext = createContext();

function AppContext({ children }) {
  const [balance, setBalance] = useState(0);
  const [LoggedIn, setLoggedIn] = useState(false);

  const data = {
    balance,
    setBalance,
    LoggedIn,
    setLoggedIn,
  };

  return <UserContext.Provider value={data}>{children}</UserContext.Provider>;
}

export default AppContext;
