import { useSelector } from 'react-redux';


const useAppSelector = useSelector;
export default useAppSelector;
