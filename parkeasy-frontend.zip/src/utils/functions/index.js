export { default as isEmail } from './isEmail';
export { default as isPassword } from './isPassword';
export { default as ifCondition } from './ifCondition';
